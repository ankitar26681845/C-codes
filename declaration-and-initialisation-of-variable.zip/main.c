//write a program to declare and intialize variables and display them 
#include<stdio.h>
int main()
{
    int a=5;
    printf("my name is Ankit kumar");
    
}